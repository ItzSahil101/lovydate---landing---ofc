/** @type {import('next').NextConfig} */
const nextConfig = {
  /* Railpack / Nixpacks ready */
  images: {
    unoptimized: true,
  },
};

export default nextConfig;
