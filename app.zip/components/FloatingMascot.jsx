"use client";

import React, { useState, useEffect, useRef } from "react";
import Image from "next/image";
import {
  MessageSquare, X, Send, ChevronLeft, Plus,
  LifeBuoy, Headphones, CheckCircle2, Clock, User, Shield, Lock,
  AlertTriangle, Paperclip, ImageIcon, ZoomIn
} from "lucide-react";

export function formatRole(role) {
  if (!role) return "Support";
  const map = {
    SUPER_ADMIN: "Super Admin",
    MODERATOR: "Moderator",
    SUPPORT: "Support",
    MARKETER: "Marketer",
    ANALYST: "Analyst",
    CUSTOMER: "Customer",
    USER: "Customer",
  };
  return map[role.toUpperCase()] || role.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

function timeAgo(dateString) {
  if (!dateString) return "Active now";
  const diffMs = Date.now() - new Date(dateString).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 2) return "Active now";
  if (mins < 60) return `Active ${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `Active ${hours}h ago`;
  return "Active recently";
}

export default function FloatingMascot() {
  const [isOpen, setIsOpen] = useState(false);
  const [view, setView] = useState("home"); // 'home', 'new', 'chat'
  const [activeTicketId, setActiveTicketId] = useState(null);
  const [recentTickets, setRecentTickets] = useState([]);

  // Form State
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState("Account & Login");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  // Chat State
  const [ticketData, setTicketData] = useState(null);
  const [replyMessage, setReplyMessage] = useState("");
  const [attachments, setAttachments] = useState([]);
  const [isSendingReply, setIsSendingReply] = useState(false);
  const [previewImageModal, setPreviewImageModal] = useState(null);

  const fileInputRef = useRef(null);
  const messagesEndRef = useRef(null);

  // Load stored tickets from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem("lovydate_support_tickets");
      if (stored) {
        setRecentTickets(JSON.parse(stored));
      }
      const savedEmail = localStorage.getItem("lovydate_support_email");
      const savedName = localStorage.getItem("lovydate_support_name");
      if (savedEmail) setEmail(savedEmail);
      if (savedName) setName(savedName);
    } catch (e) {
      console.error(e);
    }
  }, []);

  // Poll active ticket messages every 3 seconds when chat is open
  useEffect(() => {
    if (!isOpen || view !== "chat" || !activeTicketId) return;

    const fetchTicket = async () => {
      try {
        const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";
        const res = await fetch(`${apiUrl}/api/v1/support/tickets/${activeTicketId}`);
        if (res.ok) {
          const json = await res.json();
          setTicketData(json.data);
        }
      } catch (err) {
        console.error(err);
      }
    };

    fetchTicket();
    const interval = setInterval(fetchTicket, 3000);
    return () => clearInterval(interval);
  }, [isOpen, view, activeTicketId]);

  // Scroll to bottom of message stream
  useEffect(() => {
    if (view === "chat") {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [ticketData?.messages, view]);

  // Handle image file selection
  const handleFileChange = (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    files.forEach((file) => {
      if (!file.type.startsWith("image/")) {
        alert("Please select image files (PNG, JPG, WEBP).");
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        setAttachments((prev) => [...prev, event.target.result]);
      };
      reader.readAsDataURL(file);
    });

    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // Create new ticket
  const handleStartTicket = async (e) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || (!message.trim() && attachments.length === 0)) return;

    setIsSubmitting(true);
    setErrorMsg("");
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";
      const res = await fetch(`${apiUrl}/api/v1/support/tickets`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          subject: subject.trim() || category,
          category,
          message: message.trim(),
          attachments,
        }),
      });

      if (res.ok) {
        const json = await res.json();
        const created = json.data;

        localStorage.setItem("lovydate_support_email", email.trim());
        localStorage.setItem("lovydate_support_name", name.trim());

        const updated = [
          { id: created.id, subject: created.subject, category: created.category, createdAt: new Date().toISOString() },
          ...recentTickets.filter((t) => t.id !== created.id),
        ];
        setRecentTickets(updated);
        localStorage.setItem("lovydate_support_tickets", JSON.stringify(updated));

        setActiveTicketId(created.id);
        setMessage("");
        setSubject("");
        setAttachments([]);
        setView("chat");
      } else {
        const errJson = await res.json();
        setErrorMsg(errJson.error?.message || "Failed to create support ticket.");
      }
    } catch (err) {
      setErrorMsg("Network error connecting to support server.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Send reply in existing ticket
  const handleSendReply = async (e) => {
    e.preventDefault();
    if ((!replyMessage.trim() && attachments.length === 0) || !activeTicketId) return;

    setIsSendingReply(true);
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";
      const res = await fetch(`${apiUrl}/api/v1/support/tickets/${activeTicketId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name || "Customer",
          message: replyMessage.trim(),
          attachments,
        }),
      });

      if (res.ok) {
        const json = await res.json();
        setTicketData((prev) => ({
          ...prev,
          messages: [...(prev?.messages || []), json.data],
        }));
        setReplyMessage("");
        setAttachments([]);
      } else {
        const errJson = await res.json();
        if (errJson.error?.code === "MESSAGING_RESTRICTED" || res.status === 403) {
          setTicketData((prev) => ({
            ...prev,
            isRestricted: true,
            restrictionReason: errJson.error?.message || "Messaging privileges are disabled on your account.",
          }));
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSendingReply(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-auto select-none font-sans">
      {/* Interactive Support Drawer Popup */}
      {isOpen && (
        <div className="mb-3 w-[92vw] sm:w-[410px] h-[590px] max-h-[84vh] bg-white rounded-3xl shadow-2xl border border-[#E2D6CE]/90 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-300">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#FF4124] via-[#FF6A2A] to-[#FF8A28] p-4 text-white flex items-center justify-between shadow-md">
            <div className="flex items-center gap-3">
              {view !== "home" && (
                <button
                  onClick={() => setView("home")}
                  className="p-1.5 hover:bg-white/20 rounded-full transition-colors"
                >
                  <ChevronLeft className="w-5 h-5 text-white" />
                </button>
              )}
              <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center font-black text-sm">
                <Headphones className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-sm leading-tight">LovyDate Support</h3>
                <div className="flex items-center gap-1.5 text-[11px] text-white/95 mt-0.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>
                    {ticketData?.staffLastActiveAt
                      ? timeAgo(ticketData.staffLastActiveAt)
                      : "Staff Active Now"}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1.5 hover:bg-white/20 rounded-full transition-colors text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* VIEW: Home / Ticket Selector */}
          {view === "home" && (
            <div className="flex-1 overflow-y-auto p-5 flex flex-col justify-between bg-[#FFFDFB]">
              <div className="space-y-4">
                {/* Greeting Card */}
                <div className="bg-gradient-to-br from-[#FFF5ED] to-[#FFEFE6] p-4 rounded-2xl border border-[#FF6A2A]/20">
                  <div className="flex items-center gap-2 text-[#FF4124] font-bold text-xs uppercase tracking-wider mb-1">
                    <LifeBuoy className="w-4 h-4" /> Namaste!
                  </div>
                  <h4 className="font-extrabold text-[#241713] text-base">How can we assist you today?</h4>
                  <p className="text-xs text-[#746761] mt-1">
                    Our team is here to answer profile questions, photo verification, matchmaking support, or safety reports.
                  </p>
                </div>

                {/* Action: Start New Ticket */}
                <button
                  onClick={() => setView("new")}
                  className="w-full flex items-center justify-between p-4 rounded-2xl bg-white border border-[#E2D6CE] hover:border-[#FF4124] hover:shadow-md transition-all group"
                >
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-10 h-10 rounded-xl bg-[#FFF5ED] text-[#FF4124] flex items-center justify-center font-bold">
                      <Plus className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-sm text-[#241713] group-hover:text-[#FF4124] transition-colors">
                        Start New Conversation
                      </div>
                      <div className="text-xs text-[#746761]">Typical response in &lt; 5 mins</div>
                    </div>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-[#746761] rotate-180 group-hover:translate-x-0.5 transition-transform" />
                </button>

                {/* Recent Tickets Section */}
                {recentTickets.length > 0 && (
                  <div>
                    <div className="text-[11px] font-extrabold text-[#746761] uppercase tracking-wider px-1 mb-2">
                      Recent Support Chats
                    </div>
                    <div className="space-y-2">
                      {recentTickets.slice(0, 4).map((ticket) => (
                        <div
                          key={ticket.id}
                          onClick={() => {
                            setActiveTicketId(ticket.id);
                            setView("chat");
                          }}
                          className="p-3 bg-white rounded-xl border border-[#E2D6CE] hover:border-[#FF4124]/60 cursor-pointer transition-all flex items-center justify-between"
                        >
                          <div className="min-w-0 flex-1 mr-2">
                            <div className="font-bold text-xs text-[#241713] truncate">{ticket.subject}</div>
                            <div className="text-[10px] text-[#746761] flex items-center gap-2 mt-0.5">
                              <span>{ticket.category}</span>
                              <span>•</span>
                              <span>{new Date(ticket.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                          <span className="text-[10px] font-bold text-[#FF4124] bg-[#FFF5ED] px-2.5 py-1 rounded-full">
                            Open Chat →
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="text-center text-[11px] text-[#746761] pt-4 border-t border-[#E2D6CE]">
                🔒 256-bit encrypted live customer support
              </div>
            </div>
          )}

          {/* VIEW: New Ticket Form */}
          {view === "new" && (
            <form onSubmit={handleStartTicket} className="flex-1 overflow-y-auto p-5 flex flex-col justify-between bg-[#FFFDFB]">
              <div className="space-y-3">
                <h4 className="font-bold text-sm text-[#241713]">Start a Support Ticket</h4>

                {errorMsg && (
                  <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-[#241713] mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Maya Shrestha"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white rounded-xl border border-[#E2D6CE] focus:outline-none focus:border-[#FF4124]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#241713] mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="maya@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white rounded-xl border border-[#E2D6CE] focus:outline-none focus:border-[#FF4124]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#241713] mb-1">Topic Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white rounded-xl border border-[#E2D6CE] focus:outline-none focus:border-[#FF4124]"
                  >
                    <option value="Account & Login">Account & Login</option>
                    <option value="Verification & Photos">Verification & Photos</option>
                    <option value="Matches & Discovery">Matches & Discovery</option>
                    <option value="Safety & Reporting">Safety & User Reporting</option>
                    <option value="Feedback & Suggestions">Feedback & Suggestions</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#241713] mb-1">How can we help? *</label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Describe your issue or question..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white rounded-xl border border-[#E2D6CE] focus:outline-none focus:border-[#FF4124]"
                  />
                </div>

                {/* Media Attachment in New Form */}
                {attachments.length > 0 && (
                  <div className="flex gap-2 flex-wrap pt-1">
                    {attachments.map((img, i) => (
                      <div key={i} className="relative w-12 h-12 rounded-lg border border-[#E2D6CE] overflow-hidden group">
                        <img src={img} alt="attachment" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => setAttachments(attachments.filter((_, idx) => idx !== i))}
                          className="absolute inset-0 bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-3">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 bg-gradient-to-r from-[#FF4124] to-[#FF8A28] text-white font-bold text-xs rounded-xl shadow-lg hover:opacity-95 transition-opacity disabled:opacity-50"
                >
                  {isSubmitting ? "Connecting to Staff..." : "Submit Ticket & Start Chat"}
                </button>
              </div>
            </form>
          )}

          {/* VIEW: Live Chat Thread */}
          {view === "chat" && (
            <div className="flex-1 flex flex-col bg-[#FAF7F2] overflow-hidden">
              {/* Ticket Status Bar */}
              <div className="bg-white px-4 py-2.5 border-b border-[#E2D6CE] flex items-center justify-between text-xs">
                <div className="font-bold text-[#241713] truncate max-w-[200px]">
                  {ticketData?.subject || ticketData?.category || "Support Inquiry"}
                </div>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                  ticketData?.isRestricted
                    ? "bg-red-100 text-red-800"
                    : ticketData?.status === "resolved"
                    ? "bg-slate-100 text-slate-700"
                    : "bg-emerald-50 text-emerald-700"
                }`}>
                  {ticketData?.isRestricted ? "RESTRICTED" : ticketData?.status?.toUpperCase() || "OPEN"}
                </span>
              </div>

              {/* Messages Stream */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
                {ticketData?.messages?.map((msg) => {
                  const isAdmin = msg.senderType === "admin";
                  const roleName = formatRole(msg.senderRole || (isAdmin ? "Super Admin" : "Customer"));
                  const msgAttachments = Array.isArray(msg.attachments) ? msg.attachments : [];

                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isAdmin ? "items-start" : "items-end"}`}
                    >
                      {/* Sender Name & Role Label */}
                      <div className="flex items-center gap-1.5 mb-1 px-1">
                        <span className="text-[11.5px] font-extrabold text-[#241713]">
                          {isAdmin ? `Sent by ${msg.senderName || "Support Specialist"}` : "You"}
                        </span>
                        {isAdmin && (
                          <span className="text-[9.5px] font-bold bg-[#FFF4EE] text-[#FF4124] border border-[#FF6A2A]/20 px-2 py-0.2 rounded-full">
                            {roleName}
                          </span>
                        )}
                        <span className="text-[10px] text-[#746761]">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </span>
                      </div>

                      {/* Bubble */}
                      <div
                        className={`max-w-[85%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                          isAdmin
                            ? "bg-white text-[#241713] rounded-tl-sm border border-[#E2D6CE] shadow-sm"
                            : "bg-[#FF4124] text-white rounded-tr-sm shadow-sm"
                        }`}
                      >
                        {msg.message && <div>{msg.message}</div>}

                        {/* Image Attachments */}
                        {msgAttachments.length > 0 && (
                          <div className={`flex flex-wrap gap-2 ${msg.message ? "mt-2 pt-2 border-t border-black/10" : ""}`}>
                            {msgAttachments.map((imgUrl, idx) => (
                              <div
                                key={idx}
                                onClick={() => setPreviewImageModal(imgUrl)}
                                className="relative w-28 h-28 rounded-xl overflow-hidden cursor-pointer border border-black/10 hover:opacity-90 transition-opacity"
                              >
                                <img src={imgUrl} alt="Attached media" className="w-full h-full object-cover" />
                                <div className="absolute bottom-1 right-1 p-1 bg-black/50 text-white rounded-md">
                                  <ZoomIn className="w-3 h-3" />
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Reply Input Bar OR Resolved Block OR Restricted Locked Input */}
              {ticketData?.status === "resolved" || ticketData?.status === "closed" ? (
                <div className="p-4 bg-[#F8F9FA] border-t border-[#EAE3DE] text-center flex flex-col items-center gap-1.5">
                  <div className="text-xs font-bold text-[#241713] flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Conversation ended • Ticket resolved
                  </div>
                  <div className="text-[11px] text-[#746761]">
                    This support inquiry has been marked as resolved.
                  </div>
                  <button
                    type="button"
                    onClick={() => setView("new")}
                    className="mt-1 px-4 py-1.5 bg-gradient-to-r from-[#FF4124] to-[#FF8A28] text-white text-[11px] font-bold rounded-full shadow-sm hover:opacity-95 transition-opacity"
                  >
                    Start New Conversation
                  </button>
                </div>
              ) : ticketData?.isRestricted ? (
                <div className="p-3.5 bg-slate-50 border-t border-slate-200 text-center text-xs font-semibold text-slate-700">
                  Messaging privileges are disabled on your account.
                </div>
              ) : (
                <div className="p-3 bg-white border-t border-[#E2D6CE]">
                  {/* Attachment Preview Chip */}
                  {attachments.length > 0 && (
                    <div className="flex gap-2 mb-2">
                      {attachments.map((img, i) => (
                        <div key={i} className="relative w-12 h-12 rounded-xl border border-[#E2D6CE] overflow-hidden group">
                          <img src={img} alt="attachment" className="w-full h-full object-cover" />
                          <button
                            type="button"
                            onClick={() => setAttachments(attachments.filter((_, idx) => idx !== i))}
                            className="absolute inset-0 bg-black/60 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <form onSubmit={handleSendReply} className="flex items-center gap-2">
                    {/* Media Upload Button */}
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      accept="image/*"
                      multiple
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="p-2.5 text-[#746761] hover:text-[#FF4124] hover:bg-[#FFF5ED] rounded-xl transition-colors"
                      title="Attach image or screenshot"
                    >
                      <ImageIcon className="w-4 h-4" />
                    </button>

                    <input
                      type="text"
                      placeholder="Type your reply..."
                      value={replyMessage}
                      onChange={(e) => setReplyMessage(e.target.value)}
                      className="flex-1 text-xs p-2.5 bg-[#FFFDFB] rounded-xl border border-[#E2D6CE] focus:outline-none focus:border-[#FF4124]"
                    />

                    <button
                      type="submit"
                      disabled={(!replyMessage.trim() && attachments.length === 0) || isSendingReply}
                      className="p-2.5 bg-gradient-to-r from-[#FF4124] to-[#FF8A28] text-white rounded-xl disabled:opacity-50 transition-opacity shadow-md hover:shadow-orange-500/20"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Fullscreen Image Preview Lightbox */}
      {previewImageModal && (
        <div
          onClick={() => setPreviewImageModal(null)}
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 animate-in fade-in"
        >
          <div className="relative max-w-2xl max-h-[85vh] overflow-hidden rounded-2xl bg-black">
            <img src={previewImageModal} alt="Preview" className="w-full h-full object-contain" />
            <button
              onClick={() => setPreviewImageModal(null)}
              className="absolute top-3 right-3 p-2 rounded-full bg-black/60 text-white hover:bg-black/90 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Standalone Transparent Floating Mascot Trigger (Opens Support Ticket) */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="relative group cursor-pointer transform hover:scale-105 active:scale-95 transition-all duration-300 focus:outline-none flex flex-col items-center"
          aria-label="Open Lovydate Support Ticket"
        >
          {/* Character Mascot Image */}
          <div className="relative w-20 h-24 sm:w-24 sm:h-28 animate-float drop-shadow-[0_12px_18px_rgba(0,0,0,0.22)]">
            <Image
              src="/assets/mascot_namaste_clean.png"
              alt="Lovydate Mascot Support"
              fill
              priority
              className="object-contain"
            />
            {/* Small Support Icon Badge */}
            <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-gradient-to-r from-[#FF4124] to-[#FF8A28] text-white flex items-center justify-center shadow-lg border-2 border-white">
              <Headphones className="w-3.5 h-3.5" />
            </div>
          </div>
        </button>
      )}
    </div>
  );
}
