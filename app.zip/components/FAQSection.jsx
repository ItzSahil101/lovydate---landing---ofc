"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState(0);

  const faqs = [
    {
      q: "Is Lovydate completely free to download and use in Nepal?",
      a: "Yes! Lovydate is 100% free to download. You can create your profile, add your passions and prompts, discover matches, and chat with mutual connections without paying a subscription.",
    },
    {
      q: "How does the Thunder Spark™ Compatibility match work?",
      a: "Our algorithm calculates compatibility by comparing your dating intentions, lifestyle preferences, common passions, and values to recommend the highest chemistry matches in your area.",
    },
    {
      q: "How does Lovydate protect my safety and privacy?",
      a: "We protect you with mutual match locking (chat opens only when both people like each other), optional Incognito mode, approximate distance masking, and a responsive one-tap block and reporting tool.",
    },
    {
      q: "Is my exact location visible to other users?",
      a: "No. Lovydate never discloses your exact GPS coordinate or street address. We only show approximate distance (e.g. '3 km away') to protect your privacy and security at all times.",
    },
    {
      q: "When will Lovydate launch and on which platforms?",
      a: "Lovydate is launching soon across Nepal on both Android (Google Play) and iOS (App Store). Join our early access waitlist today to be notified the moment we go live!",
    },
  ];

  return (
    <section id="faq" className="py-24 relative bg-[#FFF7F2]/80">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center space-y-4 mb-16">
          <div className="inline-flex items-center px-3.5 py-1.5 rounded-full glass-card border border-[#FF6A2A]/30 text-xs font-bold text-[#FF4124]">
            <span>Got Questions?</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black font-outfit text-slate-900 tracking-tight">
            Frequently Asked <span className="text-gradient">Questions</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg font-medium">
            Everything you need to know about the Lovydate app and community in Nepal.
          </p>
        </div>

        {/* FAQ Accordion */}
        <div className="space-y-4">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="bg-white rounded-2xl border border-orange-200/70 overflow-hidden transition-all duration-300 hover:border-[#FF6A2A]/50 shadow-sm"
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? -1 : index)}
                  className="w-full p-6 text-left flex items-center justify-between gap-4 font-outfit text-lg font-bold text-slate-900 transition-colors"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-[#FF6A2A] flex-shrink-0 transition-transform duration-300 ${
                      isOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-6 pb-6 text-sm text-slate-600 font-medium leading-relaxed border-t border-orange-100 pt-4 animate-fadeIn">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
