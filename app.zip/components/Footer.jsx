"use client";

import Image from "next/image";
import Link from "next/link";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-orange-200/60 bg-[#F5EFEA] text-slate-600 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Brand Info */}
          <div className="space-y-4">
            <Link href="#" className="flex items-center gap-3">
              <div className="relative w-8 h-8 rounded-xl overflow-hidden ring-2 ring-[#FF6A2A]/50 shadow-sm">
                <Image
                  src="/assets/branding_icon.png"
                  alt="Lovydate Brand Icon"
                  fill
                  className="object-contain p-0.5 bg-white"
                />
              </div>
              <div className="relative h-6 w-24">
                <Image
                  src="/assets/textmark_icon.png"
                  alt="Lovydate"
                  fill
                  className="object-contain object-left"
                />
              </div>
            </Link>

            <p className="text-xs text-slate-600 leading-relaxed font-medium max-w-sm">
              Nepal&apos;s upcoming dating app built for authentic sparks, verified profiles, and genuine connections.
            </p>
          </div>

          {/* Quick Navigation Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-black font-outfit text-slate-900 uppercase tracking-wider">
              Quick Links
            </h4>
            <ul className="space-y-2 text-xs font-semibold">
              <li>
                <a href="#experience" className="hover:text-[#FF4124] transition-colors">
                  App Screens
                </a>
              </li>
              <li>
                <a href="#features" className="hover:text-[#FF4124] transition-colors">
                  Core Innovations
                </a>
              </li>
              <li>
                <a href="#how-it-works" className="hover:text-[#FF4124] transition-colors">
                  How It Works
                </a>
              </li>
              <li>
                <a href="#safety" className="hover:text-[#FF4124] transition-colors">
                  Safety Standards
                </a>
              </li>
              <li>
                <a href="#stories" className="hover:text-[#FF4124] transition-colors">
                  Success Stories
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-[#FF4124] transition-colors">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#waitlist" className="hover:text-[#FF4124] transition-colors">
                  Early Access Waitlist
                </a>
              </li>
            </ul>
          </div>

          {/* Safety & Privacy Features */}
          <div className="space-y-3">
            <h4 className="text-xs font-black font-outfit text-slate-900 uppercase tracking-wider">
              Safety & Controls
            </h4>
            <ul className="space-y-2 text-xs font-medium text-slate-600">
              <li>Mutual Match Chat Locking</li>
              <li>Incognito Mode</li>
              <li>Distance-Only Location Privacy</li>
              <li>Encrypted Messaging</li>
              <li>One-Tap Account Blocking</li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright line with Sameer Lamichhane attribution */}
        <div className="pt-10 mt-10 border-t border-orange-200/70 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-medium text-slate-500">
          <p>© {currentYear} Lovydate. All rights reserved. Nepal.</p>
          <div className="text-slate-600 font-semibold text-xs text-center sm:text-right">
            Designed & Developed by{" "}
            <a
              href="https://sameerlamichhane.com.np"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#FF4124] hover:underline font-bold"
            >
              Sameer Lamichhane
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
