"use client";

import Image from "next/image";

export default function HowItWorks() {
  const steps = [
    {
      number: "01",
      title: "Create Your Real Profile",
      description: "Upload your favorite photos, share your interests, and set your dating intentions in under 2 minutes.",
      badgeText: "Profile & Bio Setup",
      image: "/assets/step_1_profile.jpg",
      alt: "Woman creating dating profile on phone",
    },
    {
      number: "02",
      title: "Spark Chemistry",
      description: "Browse curated daily profiles with compatibility percentages and discover shared lifestyle passions.",
      badgeText: "Smart Compatibility",
      image: "/assets/step_2_match.jpg",
      alt: "Man discovering spark matches on mobile",
    },
    {
      number: "03",
      title: "Connect & Meet",
      description: "Engage in genuine chat conversations, connect over common hobbies, and meet up for memorable real-life dates.",
      badgeText: "Meaningful Dates",
      image: "/assets/step_3_date.jpg",
      alt: "Happy couple enjoying first dinner date",
    },
  ];

  return (
    <section id="how-it-works" className="py-24 relative overflow-hidden bg-[#FFF7F2]/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center px-3.5 py-1.5 rounded-full glass-card border border-[#FF6A2A]/30 text-xs font-bold text-[#FF4124]">
            <span>Simple 3-Step Journey</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black font-outfit text-slate-900 tracking-tight">
            How <span className="text-gradient">Lovydate</span> Works
          </h2>
          <p className="text-slate-600 text-base sm:text-lg font-medium">
            Finding your ideal partner shouldn&apos;t feel like a chore. Here is how we make meeting people simple, engaging, and heartfelt in Nepal.
          </p>
        </div>

        {/* Steps Grid with Real Lifestyle Photos */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {steps.map((step, index) => (
            <div
              key={index}
              className="relative bg-white rounded-3xl p-6 sm:p-7 border border-orange-200/70 hover:border-[#FF6A2A]/50 transition-all duration-300 flex flex-col justify-between group shadow-md shadow-orange-950/5 hover:-translate-y-1.5"
            >
              <div>
                {/* Real Lifestyle Photo Frame */}
                <div className="relative w-full h-48 rounded-2xl overflow-hidden mb-5 border-2 border-orange-200/80 shadow-md group-hover:shadow-lg transition-shadow">
                  <Image
                    src={step.image}
                    alt={step.alt}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/20" />
                  
                  {/* Floating Number Tag */}
                  <div className="absolute top-3 left-3 px-3 py-1 rounded-xl bg-slate-900/85 backdrop-blur-md text-white font-outfit font-black text-xs border border-white/20 shadow-md">
                    {step.number}
                  </div>
                </div>

                {/* Badge Tag */}
                <span className="inline-block px-3 py-1 rounded-full bg-orange-50 border border-orange-200 text-[11px] font-bold text-[#FF4124] mb-3">
                  {step.badgeText}
                </span>

                {/* Content */}
                <h3 className="text-xl font-bold font-outfit text-slate-900 mb-2">
                  {step.title}
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed font-medium">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
