"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { Menu, X, Smartphone, Sparkles, Compass, ShieldCheck, HeartHandshake, HelpCircle, ArrowRight } from "lucide-react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Prevent background scrolling when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [mobileMenuOpen]);

  const navItems = [
    { name: "App Screens", href: "#experience", num: "01", icon: Smartphone, desc: "Interactive mobile preview" },
    { name: "Features", href: "#features", num: "02", icon: Sparkles, desc: "Spark compatibility & moments feed" },
    { name: "How It Works", href: "#how-it-works", num: "03", icon: Compass, desc: "3 simple steps to connect" },
    { name: "Safety", href: "#safety", num: "04", icon: ShieldCheck, desc: "Privacy controls & mutual locking" },
    { name: "Stories", href: "#stories", num: "05", icon: HeartHandshake, desc: "Singles in Kathmandu & Pokhara" },
    { name: "FAQ", href: "#faq", num: "06", icon: HelpCircle, desc: "Common questions & launch info" },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-white/85 backdrop-blur-md border-b border-orange-200/50 shadow-sm py-3"
            : "bg-transparent py-4 sm:py-5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Brand Logo */}
            <Link href="#" className="flex items-center gap-2.5 sm:gap-3 group">
              <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-2xl overflow-hidden shadow-md shadow-[#FF4124]/20 ring-2 ring-[#FF6A2A]/40 transition-transform group-hover:scale-105">
                <Image
                  src="/assets/branding_icon.png"
                  alt="Lovydate Icon"
                  fill
                  priority
                  className="object-contain p-1 bg-white"
                />
              </div>
              <div className="relative h-6 w-24 sm:h-7 sm:w-28">
                <Image
                  src="/assets/textmark_icon.png"
                  alt="Lovydate"
                  fill
                  priority
                  className="object-contain object-left"
                />
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <div className="hidden md:flex items-center gap-7">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-sm font-semibold text-slate-700 hover:text-[#FF4124] transition-colors"
                >
                  {item.name}
                </a>
              ))}
            </div>

            {/* Desktop CTA Button */}
            <div className="hidden md:flex items-center gap-4">
              <a
                href="#waitlist"
                className="relative inline-flex items-center justify-center px-6 py-2.5 rounded-full font-bold text-sm text-white bg-gradient-to-r from-[#FF6A2A] to-[#FF4124] hover:from-[#ff7940] hover:to-[#ff5238] orange-glow transition-all duration-300 shadow-md shadow-[#FF4124]/25 hover:scale-105 active:scale-100"
              >
                <span>Get Early Access</span>
              </a>
            </div>

            {/* Mobile Menu Toggle Button */}
            <div className="md:hidden flex items-center gap-2">
              <a
                href="#waitlist"
                className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-[#FF6A2A] to-[#FF4124] text-white font-bold text-xs shadow-sm shadow-[#FF4124]/30"
              >
                Waitlist
              </a>
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-2xl bg-white/90 border border-orange-200/80 text-slate-800 hover:text-[#FF4124] hover:bg-orange-50 transition-all shadow-sm active:scale-95"
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-5 h-5 text-[#FF4124]" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Modern Full-Featured Mobile Menu Sheet */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 md:hidden flex flex-col justify-between bg-white/95 backdrop-blur-2xl animate-fadeIn pt-20 pb-8 px-5 overflow-y-auto">
          {/* Menu Header with Nepal Tag */}
          <div className="flex items-center justify-between border-b border-orange-100 pb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-[#FF4124]">
              Navigation
            </span>
            <span className="text-[11px] font-semibold text-slate-500 bg-orange-50 px-2.5 py-0.5 rounded-full border border-orange-200">
              Launching Soon in Nepal 🇳🇵
            </span>
          </div>

          {/* Navigation Links Grid with Numbering & Icons */}
          <div className="py-4 space-y-2">
            {navItems.map((item) => {
              const IconComponent = item.icon;
              return (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-white border border-orange-200/60 shadow-sm hover:border-[#FF4124]/40 active:bg-orange-50/70 transition-all group"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-8 h-8 rounded-xl bg-orange-50 border border-orange-200 text-[#FF4124] flex items-center justify-center font-outfit font-black text-xs group-hover:bg-[#FF4124] group-hover:text-white transition-colors">
                      {item.num}
                    </div>
                    <div className="text-left">
                      <div className="text-sm font-bold text-slate-900 group-hover:text-[#FF4124] transition-colors">
                        {item.name}
                      </div>
                      <div className="text-[11px] text-slate-500 font-medium">
                        {item.desc}
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#FF4124] group-hover:translate-x-1 transition-all" />
                </a>
              );
            })}
          </div>

          {/* Bottom VIP Early Access Card */}
          <div className="pt-2 space-y-3">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-[#FF4124] to-[#FF6A2A] text-white shadow-lg shadow-[#FF4124]/20 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black tracking-wider uppercase bg-white/20 px-2.5 py-1 rounded-full text-white">
                  VIP Waitlist
                </span>
                <span className="text-[11px] text-white/90 font-semibold">100% Free</span>
              </div>
              <p className="text-xs text-white/90 font-medium">
                Be the first to match when Lovydate launches in Nepal.
              </p>
              <a
                href="#waitlist"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full flex items-center justify-center py-3 rounded-full bg-slate-950 text-white font-black text-xs shadow-md hover:bg-slate-900 active:scale-95 transition-all"
              >
                Join Early Access
              </a>
            </div>

            {/* Mobile Footer Credit */}
            <div className="text-center text-[11px] text-slate-500 font-medium pt-1">
              Designed & Developed by{" "}
              <a
                href="https://sameerlamichhane.com.np"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#FF4124] font-bold"
              >
                Sameer Lamichhane
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
