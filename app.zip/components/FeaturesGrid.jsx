"use client";

import Image from "next/image";

export default function FeaturesGrid() {
  return (
    <section id="features" className="py-24 relative bg-[#FCF9F6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border border-[#FF6A2A]/30 text-xs font-bold text-[#FF4124]">
            <span>Made For Nepal</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black font-outfit text-slate-900 tracking-tight">
            Built For Meaningful <span className="text-gradient">Chemistry</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg font-medium">
            Say goodbye to fake profiles and awkward matchmaking. Lovydate combines smart matchmaking with a social moments feed to help you connect authentically.
          </p>
        </div>

        {/* Bento Grid with Clean Numbering */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Bento Card 1: 01 Spark Compatibility Algorithm with Authentic Nepali Couple Photo */}
          <div className="lg:col-span-2 bg-white rounded-3xl p-8 sm:p-10 border border-orange-200/70 relative overflow-hidden group hover:border-[#FF6A2A]/50 transition-all duration-300 shadow-md shadow-orange-950/5">
            <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-gradient-to-tl from-[#FF4124]/15 to-[#FF6A2A]/10 rounded-full blur-3xl pointer-events-none group-hover:scale-125 transition-transform duration-500" />
            
            <div className="relative z-10 flex flex-col md:flex-row items-center gap-8 justify-between">
              <div className="space-y-4 max-w-md text-left">
                {/* Numbering Badge */}
                <div className="inline-flex items-center px-3.5 py-1.5 rounded-2xl bg-gradient-to-r from-[#FF6A2A] to-[#FF4124] text-white font-outfit font-black text-sm shadow-md shadow-[#FF4124]/25">
                  01
                </div>

                <h3 className="text-2xl sm:text-3xl font-bold font-outfit text-slate-900">
                  Thunder Spark™ Smart Chemistry
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed font-medium">
                  Our matchmaking engine analyzes lifestyle priorities, personal values, cultural interests, and dating intentions to recommend high-synergy matches across Nepal.
                </p>
                <div className="flex flex-wrap gap-2 pt-2">
                  <span className="px-3 py-1 rounded-full bg-orange-50 text-xs font-bold text-[#FF4124] border border-orange-200">
                    94% higher reply rate
                  </span>
                  <span className="px-3 py-1 rounded-full bg-rose-50 text-xs font-bold text-[#E62816] border border-rose-200">
                    3x more second dates
                  </span>
                </div>
              </div>

              {/* Real Nepali Couple Match Image Card */}
              <div className="relative w-full max-w-[220px] h-52 sm:h-56 rounded-2xl overflow-hidden border-2 border-orange-200/80 shadow-xl flex-shrink-0 group-hover:scale-105 transition-transform duration-300 bg-orange-50">
                <Image
                  src="/assets/nepali_couple.jpg"
                  alt="Authentic Nepali Couple"
                  fill
                  className="object-cover object-center"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-2.5 left-2.5 right-2.5 px-3 py-1.5 rounded-xl bg-white/95 backdrop-blur-md border border-white/50 flex items-center justify-between text-[11px] font-bold text-slate-900 shadow-sm">
                  <span>Aarav & Pooja</span>
                  <span className="text-[#FF4124]">98% Spark</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bento Card 2: 02 Daily Moments & Memories Feed */}
          <div className="bg-white rounded-3xl p-8 border border-orange-200/70 relative overflow-hidden group hover:border-[#FF6A2A]/50 transition-all duration-300 shadow-md shadow-orange-950/5 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Numbering Badge */}
              <div className="inline-flex items-center px-3.5 py-1.5 rounded-2xl bg-orange-100 text-[#FF4124] font-outfit font-black text-sm border border-orange-200">
                02
              </div>

              <h3 className="text-xl font-bold font-outfit text-slate-900">
                Daily Memories & Moments Feed
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed font-medium">
                Share your daily photos, cafe visits, weekend treks, and life moments in the community feed. Connect naturally over real-life stories.
              </p>
            </div>

            {/* Visual Tags */}
            <div className="pt-6">
              <div className="flex flex-wrap gap-1.5">
                <span className="px-2.5 py-1 rounded-full bg-orange-50 border border-orange-200 text-xs font-bold text-[#FF4124]">
                  Photo Posts
                </span>
                <span className="px-2.5 py-1 rounded-full bg-orange-50 border border-orange-200 text-xs font-bold text-[#FF4124]">
                  Likes & Comments
                </span>
                <span className="px-2.5 py-1 rounded-full bg-orange-50 border border-orange-200 text-xs font-bold text-[#FF4124]">
                  Live Moments
                </span>
              </div>
            </div>
          </div>

          {/* Bento Card 3: 03 Privacy Controls & Mutual Matching */}
          <div className="bg-white rounded-3xl p-8 border border-orange-200/70 relative overflow-hidden group hover:border-[#FF4124]/40 transition-all duration-300 shadow-md shadow-orange-950/5 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Numbering Badge */}
              <div className="inline-flex items-center px-3.5 py-1.5 rounded-2xl bg-orange-100 text-[#FF4124] font-outfit font-black text-sm border border-orange-200">
                03
              </div>

              <h3 className="text-xl font-bold font-outfit text-slate-900">
                Privacy Controls & Mutual Matching
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed font-medium">
                Chat only opens upon mutual like. Toggle Incognito mode, hide online status, and manage visibility on your own terms.
              </p>
            </div>

            <div className="pt-6">
              <div className="inline-flex items-center px-3 py-1.5 rounded-xl bg-orange-50 border border-orange-200 text-xs font-bold text-[#FF4124]">
                Mutual Match Protected
              </div>
            </div>
          </div>

          {/* Bento Card 4: 04 Hyper-Local Discovery in Nepal */}
          <div className="bg-white rounded-3xl p-8 border border-orange-200/70 relative overflow-hidden group hover:border-orange-400/50 transition-all duration-300 shadow-md shadow-orange-950/5 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Numbering Badge */}
              <div className="inline-flex items-center px-3.5 py-1.5 rounded-2xl bg-orange-100 text-[#FF4124] font-outfit font-black text-sm border border-orange-200">
                04
              </div>

              <h3 className="text-xl font-bold font-outfit text-slate-900">
                Hyper-Local City Radius
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed font-medium">
                Discover singles in your exact city—Kathmandu, Lalitpur, Pokhara, Butwal, Biratnagar, or Dharan with privacy-protected radius.
              </p>
            </div>

            <div className="pt-6">
              <div className="text-xs font-semibold text-slate-600">
                Spot singles within 1 to 50 km radius
              </div>
            </div>
          </div>

          {/* Bento Card 5: 05 Thoughtful Icebreakers */}
          <div className="bg-white rounded-3xl p-8 border border-orange-200/70 relative overflow-hidden group hover:border-orange-400/50 transition-all duration-300 shadow-md shadow-orange-950/5 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Numbering Badge */}
              <div className="inline-flex items-center px-3.5 py-1.5 rounded-2xl bg-orange-100 text-[#FF4124] font-outfit font-black text-sm border border-orange-200">
                05
              </div>

              <h3 className="text-xl font-bold font-outfit text-slate-900">
                Zero Awkward Small Talk
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed font-medium">
                Engaging prompts about weekend trips, favorite food spots, and music give you natural icebreakers to start talking.
              </p>
            </div>

            <div className="pt-6">
              <div className="p-2.5 rounded-xl bg-orange-50 border border-orange-200 text-xs text-[#FF4124] font-semibold italic">
                &ldquo;My favorite momo spot in Kathmandu is...&rdquo;
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
