"use client";

import { Star, Quote } from "lucide-react";

export default function Testimonials() {
  const stories = [
    {
      couple: "Aarav & Pooja",
      location: "Kathmandu • Engaged",
      quote: "We connected over our shared passion for photography and quiet heritage cafes in Patan. Three months of coffee dates later, we introduced each other to our families. Lovydate made it so natural and respectful.",
      tag: "Engaged",
      rating: 5,
    },
    {
      couple: "Sujan & Prakriti",
      location: "Pokhara • Together 1 Year",
      quote: "Lovydate is completely different from generic apps. The compatibility match was spot-on with our values and weekend trekking lifestyle. We couldn't be happier!",
      tag: "Deep Chemistry",
      rating: 5,
    },
    {
      couple: "Rohan & Sneha",
      location: "Lalitpur • Together 2 Years",
      quote: "As busy professionals in Kathmandu, finding someone with aligned life goals and values felt impossible. Lovydate's compatibility algorithm introduced us to our forever person.",
      tag: "True Love",
      rating: 5,
    },
  ];

  return (
    <section id="stories" className="py-24 relative overflow-hidden bg-white">
      {/* Ambient background glow */}
      <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-[#FF4124]/10 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center px-3.5 py-1.5 rounded-full glass-card border border-[#FF6A2A]/30 text-xs font-bold text-[#FF4124]">
            <span>Success Stories from Nepal</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black font-outfit text-slate-900 tracking-tight">
            Matches Made For <span className="text-gradient">A Lifetime</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg font-medium">
            Couples who found their genuine spark on Lovydate share their heartfelt journeys.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stories.map((story, i) => (
            <div
              key={i}
              className="bg-[#FCF9F6] rounded-3xl p-8 border border-orange-200/70 hover:border-[#FF6A2A]/50 transition-all duration-300 flex flex-col justify-between relative group shadow-md shadow-orange-950/5 hover:-translate-y-1"
            >
              <div className="space-y-4">
                {/* Header info */}
                <div className="flex items-center justify-between">
                  <div className="flex gap-1">
                    {[...Array(story.rating)].map((_, idx) => (
                      <Star key={idx} className="w-4 h-4 fill-[#FFA451] text-[#FFA451]" />
                    ))}
                  </div>
                  <span className="px-3 py-1 rounded-full bg-orange-100 border border-orange-200 text-[11px] font-bold text-[#FF4124]">
                    {story.tag}
                  </span>
                </div>

                <Quote className="w-8 h-8 text-[#FF6A2A]/30 group-hover:text-[#FF6A2A]/70 transition-colors" />

                <p className="text-slate-700 text-sm leading-relaxed italic font-medium">
                  &ldquo;{story.quote}&rdquo;
                </p>
              </div>

              <div className="pt-6 border-t border-orange-200/60 mt-6 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#FF6A2A] to-[#FF4124] flex items-center justify-center text-white font-bold text-sm shadow-md">
                  {story.couple[0]}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 font-outfit">{story.couple}</h4>
                  <p className="text-[11px] text-slate-500 font-medium">{story.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
