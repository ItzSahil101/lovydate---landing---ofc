"use client";

import Image from "next/image";

export default function SafetySection() {
  const safetyFeatures = [
    {
      number: "01",
      title: "Mutual Match Chat Security",
      description: "Conversations only unlock when both individuals like each other, preventing uninvited messages and spam.",
    },
    {
      number: "02",
      title: "Privacy-Protected Radius",
      description: "We never reveal your exact GPS coordinate or street address. Your location details remain completely private.",
    },
    {
      number: "03",
      title: "Incognito & Visibility Mode",
      description: "Control who sees your profile, your online activity status, and distance visibility with one tap.",
    },
    {
      number: "04",
      title: "One-Tap Block & Active Reporting",
      description: "Instantly block, unmatch, or report suspicious accounts to keep the Nepali community safe and comfortable.",
    },
  ];

  return (
    <section id="safety" className="py-24 relative bg-[#FCF9F6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Visual Card */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="relative w-full max-w-md p-8 sm:p-10 rounded-3xl bg-white border-2 border-orange-200/80 shadow-xl overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-orange-100/50 rounded-full blur-2xl pointer-events-none" />
              
              <div className="relative z-10 space-y-6 text-center">
                {/* Brand Shield Badge with Official Icon */}
                <div className="w-20 h-20 mx-auto rounded-3xl bg-[#FFF7F2] border-2 border-orange-200 flex items-center justify-center shadow-md p-3">
                  <Image
                    src="/assets/branding_icon.png"
                    alt="Lovydate Security"
                    width={56}
                    height={56}
                    className="object-contain"
                  />
                </div>

                <div className="space-y-2">
                  <h3 className="text-2xl font-bold font-outfit text-slate-900">
                    Your Safety & Privacy Is Our Priority
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 font-medium leading-relaxed">
                    Dating should feel exciting and safe. We built Lovydate with powerful privacy barriers to protect your personal space and peace of mind.
                  </p>
                </div>

                {/* Verified Checklist with Clean Numbering */}
                <div className="p-5 rounded-2xl bg-[#FFF7F2] border border-orange-200 space-y-3 text-left text-xs font-semibold text-slate-800">
                  <div className="flex items-center gap-3">
                    <span className="w-5 h-5 rounded-full bg-orange-100 text-[#FF4124] flex items-center justify-center font-bold text-[10px]">1</span>
                    <span>Mutual match requirement to message</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="w-5 h-5 rounded-full bg-orange-100 text-[#FF4124] flex items-center justify-center font-bold text-[10px]">2</span>
                    <span>Incognito & hidden profile mode</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="w-5 h-5 rounded-full bg-orange-100 text-[#FF4124] flex items-center justify-center font-bold text-[10px]">3</span>
                    <span>One-tap block & reporting system</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="w-5 h-5 rounded-full bg-orange-100 text-[#FF4124] flex items-center justify-center font-bold text-[10px]">4</span>
                    <span>Secure phone OTP account authentication</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Features List */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center px-3.5 py-1.5 rounded-full glass-card border border-[#FF6A2A]/30 text-xs font-bold text-[#FF4124]">
                <span>Safety & Privacy Standard</span>
              </div>
              <h2 className="text-3xl sm:text-5xl font-black font-outfit text-slate-900 tracking-tight">
                Date With Confidence, <br />
                <span className="text-gradient">Zero Doubts.</span>
              </h2>
              <p className="text-slate-600 text-base sm:text-lg font-medium">
                We take security seriously with granular privacy settings, mutual matching, and continuous account protection.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {safetyFeatures.map((feat, i) => (
                <div
                  key={i}
                  className="p-6 rounded-2xl bg-white border border-orange-200/60 shadow-sm hover:border-[#FF4124]/40 transition-colors space-y-3"
                >
                  <div className="inline-flex items-center px-3 py-1 rounded-xl bg-orange-100 text-[#FF4124] font-outfit font-black text-xs border border-orange-200">
                    {feat.number}
                  </div>
                  <h4 className="text-base font-bold text-slate-900">{feat.title}</h4>
                  <p className="text-xs text-slate-600 leading-relaxed font-medium">
                    {feat.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
