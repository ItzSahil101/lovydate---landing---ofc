"use client";

import { useState } from "react";
import Image from "next/image";
import { Check } from "lucide-react";

export default function DownloadBanner() {
  const [contact, setContact] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!contact.trim()) return;

    setLoading(true);
    setErrorMsg("");

    try {
      const res = await fetch("/api/waitlist", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ contact: contact.trim() }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setSubmitted(true);
      } else {
        setErrorMsg(data.error || "Failed to submit. Please try again.");
      }
    } catch (err) {
      console.error("Submission error:", err);
      setSubmitted(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="waitlist" className="py-24 relative overflow-visible bg-[#FCF9F6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative pt-10 sm:pt-14">
        
        {/* Tilted Hanging Mascot on Top-Right Corner of Card */}
        <div className="absolute top-0 sm:top-2 right-8 sm:right-16 z-30 transform rotate-12 hover:rotate-6 transition-transform duration-300 drop-shadow-[0_20px_25px_rgba(0,0,0,0.35)] pointer-events-none">
          <div className="relative w-32 h-32 sm:w-44 sm:h-44 md:w-52 md:h-52">
            <Image
              src="/assets/onboard_icon.png"
              alt="Lovydate Onboarding Mascot"
              fill
              className="object-contain"
            />
          </div>
        </div>

        {/* Main Card */}
        <div className="relative rounded-[3rem] p-8 sm:p-14 lg:p-16 bg-gradient-to-br from-[#FF4124] via-[#FF5833] to-[#FF7A45] border-2 border-orange-300/40 shadow-2xl overflow-hidden orange-glow-lg text-white">
          {/* Properly Contained & Aligned Background Artwork (Within Card Boundaries) */}
          <div className="absolute right-0 bottom-0 w-full sm:w-4/5 lg:w-3/5 h-full pointer-events-none select-none">
            <Image
              src="/assets/loginscreen_bottom.png"
              alt="Lovydate Background Art"
              fill
              className="object-contain object-right-bottom opacity-75"
            />
          </div>

          {/* Left-side subtle gradient shield for text readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#FF4124] via-[#FF4124]/70 to-transparent pointer-events-none" />

          {/* Radiant background orb effects */}
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-white/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-20 -left-20 w-[400px] h-[400px] bg-yellow-300/15 rounded-full blur-3xl pointer-events-none" />

          {/* Card Content */}
          <div className="relative z-10 max-w-2xl space-y-6 text-center lg:text-left">
            {/* Tag */}
            <div className="inline-flex items-center px-3.5 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-xs font-extrabold text-white">
              <span>Launching Soon Across Nepal</span>
            </div>

            {/* Headline */}
            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black font-outfit text-white tracking-tight leading-[1.1] drop-shadow-sm">
              Be The First To Spark. <br />
              <span className="text-yellow-100">Join Early Access.</span>
            </h2>

            {/* Description */}
            <p className="text-white/95 text-base sm:text-lg max-w-xl font-medium leading-relaxed drop-shadow-sm">
              Lovydate is launching soon on Google Play & App Store. Pre-register now to receive VIP founding member benefits and be notified the moment we go live.
            </p>

            {/* Interactive Pre-Registration Form */}
            <div className="pt-2 max-w-md mx-auto lg:mx-0">
              {submitted ? (
                <div className="p-4 rounded-2xl bg-white text-slate-900 font-bold flex items-center gap-3 shadow-xl animate-fadeIn">
                  <div className="w-8 h-8 rounded-full bg-orange-100 text-[#FF4124] flex items-center justify-center flex-shrink-0">
                    <Check className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-outfit font-black text-slate-900">You&apos;re On The VIP List!</div>
                    <div className="text-xs text-slate-500 font-medium">We will notify you immediately upon launch.</div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-2">
                  <div className="flex flex-col sm:flex-row gap-3">
                    <input
                      type="text"
                      value={contact}
                      onChange={(e) => setContact(e.target.value)}
                      placeholder="Enter your email or phone number"
                      required
                      disabled={loading}
                      className="flex-1 bg-white px-5 py-4 rounded-full text-slate-900 placeholder-slate-400 text-sm font-medium focus:outline-none shadow-lg border border-white/80 disabled:opacity-70"
                    />
                    <button
                      type="submit"
                      disabled={loading}
                      className="px-8 py-4 rounded-full bg-slate-950 text-white font-bold text-sm hover:bg-slate-900 transition-all duration-300 shadow-xl flex items-center justify-center hover:scale-105 active:scale-100 disabled:opacity-75 flex-shrink-0"
                    >
                      <span>{loading ? "Registering..." : "Pre-Register"}</span>
                    </button>
                  </div>
                  {errorMsg && (
                    <p className="text-xs text-red-100 bg-red-950/40 px-3 py-1.5 rounded-xl text-center">
                      {errorMsg}
                    </p>
                  )}
                </form>
              )}
            </div>

            {/* Pre-launch badges */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-4 text-xs font-semibold text-white/95">
              <span className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-white" />
                VIP Founding Badge
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-white" />
                100% Free & Verified
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-white" />
                Coming to Android & iOS
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
