"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  MessageSquare, X, Send, ChevronLeft, Plus,
  Sparkles, CheckCircle2, Clock, User, Shield, Lock, AlertTriangle
} from "lucide-react";

export function SupportChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [view, setView] = useState("home"); // 'home', 'new', 'chat'
  const [activeTicketId, setActiveTicketId] = useState(null);
  const [recentTickets, setRecentTickets] = useState([]);

  // Form State
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState("Account & Login");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  // Chat State
  const [ticketData, setTicketData] = useState(null);
  const [replyMessage, setReplyMessage] = useState("");
  const [isSendingReply, setIsSendingReply] = useState(false);

  const messagesEndRef = useRef(null);

  // Load stored tickets from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem("lovydate_support_tickets");
      if (stored) {
        setRecentTickets(JSON.parse(stored));
      }
      const savedEmail = localStorage.getItem("lovydate_support_email");
      const savedName = localStorage.getItem("lovydate_support_name");
      if (savedEmail) setEmail(savedEmail);
      if (savedName) setName(savedName);
    } catch (e) {
      console.error(e);
    }
  }, []);

  // Poll active ticket messages every 3 seconds when chat is open
  useEffect(() => {
    if (!isOpen || view !== "chat" || !activeTicketId) return;

    const fetchTicket = async () => {
      try {
        const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";
        const res = await fetch(`${apiUrl}/api/v1/support/tickets/${activeTicketId}`);
        if (res.ok) {
          const json = await res.json();
          setTicketData(json.data);
        }
      } catch (err) {
        console.error(err);
      }
    };

    fetchTicket();
    const interval = setInterval(fetchTicket, 3000);
    return () => clearInterval(interval);
  }, [isOpen, view, activeTicketId]);

  // Scroll to bottom of message stream
  useEffect(() => {
    if (view === "chat") {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [ticketData?.messages, view]);

  // Create new ticket
  const handleStartTicket = async (e) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;

    setIsSubmitting(true);
    setErrorMsg("");
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";
      const res = await fetch(`${apiUrl}/api/v1/support/tickets`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          subject: subject.trim() || category,
          category,
          message: message.trim(),
        }),
      });

      if (res.ok) {
        const json = await res.json();
        const created = json.data;

        localStorage.setItem("lovydate_support_email", email.trim());
        localStorage.setItem("lovydate_support_name", name.trim());

        const updated = [
          { id: created.id, subject: created.subject, category: created.category, createdAt: new Date().toISOString() },
          ...recentTickets.filter((t) => t.id !== created.id),
        ];
        setRecentTickets(updated);
        localStorage.setItem("lovydate_support_tickets", JSON.stringify(updated));

        setActiveTicketId(created.id);
        setMessage("");
        setSubject("");
        setView("chat");
      } else {
        const errJson = await res.json();
        setErrorMsg(errJson.error?.message || "Failed to create support ticket.");
      }
    } catch (err) {
      setErrorMsg("Network error connecting to support server.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Send reply in existing ticket
  const handleSendReply = async (e) => {
    e.preventDefault();
    if (!replyMessage.trim() || !activeTicketId) return;

    setIsSendingReply(true);
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";
      const res = await fetch(`${apiUrl}/api/v1/support/tickets/${activeTicketId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name || "Customer",
          message: replyMessage.trim(),
        }),
      });

      if (res.ok) {
        const json = await res.json();
        setTicketData((prev) => ({
          ...prev,
          messages: [...(prev?.messages || []), json.data],
        }));
        setReplyMessage("");
      } else {
        const errJson = await res.json();
        if (errJson.error?.code === "MESSAGING_RESTRICTED" || res.status === 403) {
          setTicketData((prev) => ({
            ...prev,
            isRestricted: true,
            restrictionReason: errJson.error?.message || "Your messaging privileges are restricted.",
          }));
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSendingReply(false);
    }
  };

  return (
    <>
      {/* Floating Launcher Button */}
      <div className="fixed bottom-6 right-6 z-50">
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            className="group flex items-center gap-3 bg-gradient-to-r from-[#FF4124] to-[#FF8A28] text-white p-3.5 sm:px-5 sm:py-3.5 rounded-full shadow-2xl hover:scale-105 hover:shadow-orange-500/30 transition-all duration-300"
            aria-label="Open Customer Support Chat"
          >
            <div className="relative">
              <MessageSquare className="w-6 h-6 text-white" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 border-2 border-white rounded-full animate-pulse" />
            </div>
            <span className="hidden sm:inline font-bold text-sm tracking-wide">
              Live Support
            </span>
          </button>
        )}
      </div>

      {/* Floating Messenger Window */}
      {isOpen && (
        <div className="fixed bottom-5 right-5 sm:bottom-6 sm:right-6 z-50 w-[92vw] sm:w-[400px] h-[580px] max-h-[85vh] bg-white rounded-3xl shadow-2xl border border-[#E2D6CE]/80 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-300">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#FF4124] via-[#FF6A2A] to-[#FF8A28] p-4 text-white flex items-center justify-between shadow-md">
            <div className="flex items-center gap-3">
              {view !== "home" && (
                <button
                  onClick={() => setView("home")}
                  className="p-1 hover:bg-white/20 rounded-full transition-colors"
                >
                  <ChevronLeft className="w-5 h-5 text-white" />
                </button>
              )}
              <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center font-black text-sm">
                LD
              </div>
              <div>
                <h3 className="font-bold text-sm leading-tight">LovyDate Support</h3>
                <div className="flex items-center gap-1.5 text-[11px] text-white/90">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Online • Staff Active</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1.5 hover:bg-white/20 rounded-full transition-colors text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* VIEW: Home / Ticket Selector */}
          {view === "home" && (
            <div className="flex-1 overflow-y-auto p-5 flex flex-col justify-between bg-[#FFFDFB]">
              <div className="space-y-4">
                {/* Hero Greeting Card */}
                <div className="bg-gradient-to-br from-[#FFF5ED] to-[#FFEFE6] p-4 rounded-2xl border border-[#FF6A2A]/20">
                  <div className="flex items-center gap-2 text-[#FF4124] font-bold text-xs uppercase tracking-wider mb-1">
                    <Sparkles className="w-4 h-4" /> Namaste!
                  </div>
                  <h4 className="font-extrabold text-[#241713] text-base">How can we assist you today?</h4>
                  <p className="text-xs text-[#746761] mt-1">
                    Our team is here to answer profile questions, matchmaking support, or safety reports.
                  </p>
                </div>

                {/* Action: Start New Ticket */}
                <button
                  onClick={() => setView("new")}
                  className="w-full flex items-center justify-between p-4 rounded-2xl bg-white border border-[#E2D6CE] hover:border-[#FF4124] hover:shadow-md transition-all group"
                >
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-10 h-10 rounded-xl bg-[#FFF5ED] text-[#FF4124] flex items-center justify-center font-bold">
                      <Plus className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-bold text-sm text-[#241713] group-hover:text-[#FF4124] transition-colors">
                        Start New Conversation
                      </div>
                      <div className="text-xs text-[#746761]">Typical response in &lt; 5 mins</div>
                    </div>
                  </div>
                  <ChevronLeft className="w-4 h-4 text-[#746761] rotate-180 group-hover:translate-x-0.5 transition-transform" />
                </button>

                {/* Recent Tickets Section */}
                {recentTickets.length > 0 && (
                  <div>
                    <div className="text-[11px] font-extrabold text-[#746761] uppercase tracking-wider px-1 mb-2">
                      Recent Support Chats
                    </div>
                    <div className="space-y-2">
                      {recentTickets.slice(0, 4).map((ticket) => (
                        <div
                          key={ticket.id}
                          onClick={() => {
                            setActiveTicketId(ticket.id);
                            setView("chat");
                          }}
                          className="p-3 bg-white rounded-xl border border-[#E2D6CE] hover:border-[#FF4124]/60 cursor-pointer transition-all flex items-center justify-between"
                        >
                          <div className="min-w-0 flex-1 mr-2">
                            <div className="font-bold text-xs text-[#241713] truncate">{ticket.subject}</div>
                            <div className="text-[10px] text-[#746761] flex items-center gap-2 mt-0.5">
                              <span>{ticket.category}</span>
                              <span>•</span>
                              <span>{new Date(ticket.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                          <span className="text-[10px] font-bold text-[#FF4124] bg-[#FFF5ED] px-2 py-0.5 rounded-full">
                            View
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="text-center text-[11px] text-[#746761] pt-4 border-t border-[#E2D6CE]">
                🔒 256-bit encrypted secure live customer support
              </div>
            </div>
          )}

          {/* VIEW: New Ticket Form */}
          {view === "new" && (
            <form onSubmit={handleStartTicket} className="flex-1 overflow-y-auto p-5 flex flex-col justify-between bg-[#FFFDFB]">
              <div className="space-y-3">
                <h4 className="font-bold text-sm text-[#241713]">Start a Support Ticket</h4>

                {errorMsg && (
                  <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-[#241713] mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Maya Shrestha"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white rounded-xl border border-[#E2D6CE] focus:outline-none focus:border-[#FF4124]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#241713] mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="maya@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white rounded-xl border border-[#E2D6CE] focus:outline-none focus:border-[#FF4124]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#241713] mb-1">Topic Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white rounded-xl border border-[#E2D6CE] focus:outline-none focus:border-[#FF4124]"
                  >
                    <option value="Account & Login">Account & Login</option>
                    <option value="Verification & Photos">Verification & Photos</option>
                    <option value="Matches & Discovery">Matches & Discovery</option>
                    <option value="Safety & Reporting">Safety & User Reporting</option>
                    <option value="Feedback & Suggestions">Feedback & Suggestions</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#241713] mb-1">How can we help? *</label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Describe your issue or question..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full text-xs p-2.5 bg-white rounded-xl border border-[#E2D6CE] focus:outline-none focus:border-[#FF4124]"
                  />
                </div>
              </div>

              <div className="pt-3">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 bg-gradient-to-r from-[#FF4124] to-[#FF8A28] text-white font-bold text-xs rounded-xl shadow-lg hover:opacity-95 transition-opacity disabled:opacity-50"
                >
                  {isSubmitting ? "Connecting to Agent..." : "Start Live Chat"}
                </button>
              </div>
            </form>
          )}

          {/* VIEW: Live Chat Thread */}
          {view === "chat" && (
            <div className="flex-1 flex flex-col bg-[#FAF7F2] overflow-hidden">
              {/* Ticket Status Bar */}
              <div className="bg-white px-4 py-2.5 border-b border-[#E2D6CE] flex items-center justify-between text-xs">
                <div className="font-bold text-[#241713] truncate max-w-[200px]">
                  {ticketData?.subject || "Support Ticket"}
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  ticketData?.isRestricted
                    ? "bg-red-100 text-red-800"
                    : ticketData?.status === "resolved"
                    ? "bg-slate-100 text-slate-700"
                    : "bg-emerald-50 text-emerald-700"
                }`}>
                  {ticketData?.isRestricted ? "RESTRICTED" : ticketData?.status?.toUpperCase() || "OPEN"}
                </span>
              </div>

              {/* Messages Stream */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {ticketData?.messages?.map((msg) => {
                  const isAdmin = msg.senderType === "admin";
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isAdmin ? "items-start" : "items-end"}`}
                    >
                      {/* Sender Name & Role Label */}
                      <div className="flex items-center gap-1.5 mb-1 px-1">
                        <span className="text-[11px] font-extrabold text-[#241713]">
                          {isAdmin ? msg.senderName || "Support Specialist" : "You"}
                        </span>
                        {isAdmin && (
                          <span className="text-[9px] font-bold bg-[#FF4124]/10 text-[#FF4124] px-1.5 py-0.2 rounded-full uppercase">
                            {msg.senderRole || "SUPPORT"}
                          </span>
                        )}
                        <span className="text-[10px] text-[#746761]">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </span>
                      </div>

                      {/* Bubble */}
                      <div
                        className={`max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed ${
                          isAdmin
                            ? "bg-white text-[#241713] rounded-tl-sm border border-[#E2D6CE] shadow-sm"
                            : "bg-[#FF4124] text-white rounded-tr-sm shadow-sm"
                        }`}
                      >
                        {msg.message}
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Reply Input Bar OR Resolved Block OR Restricted Locked Input */}
              {ticketData?.status === "resolved" || ticketData?.status === "closed" ? (
                <div className="p-4 bg-[#F8F9FA] border-t border-[#EAE3DE] text-center flex flex-col items-center gap-1.5">
                  <div className="text-xs font-bold text-[#241713] flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Conversation ended • Ticket resolved
                  </div>
                  <div className="text-[11px] text-[#746761]">
                    This support inquiry has been marked as resolved.
                  </div>
                  <button
                    type="button"
                    onClick={() => setView("new")}
                    className="mt-1 px-4 py-1.5 bg-gradient-to-r from-[#FF4124] to-[#FF8A28] text-white text-[11px] font-bold rounded-full shadow-sm hover:opacity-95 transition-opacity"
                  >
                    Start New Conversation
                  </button>
                </div>
              ) : ticketData?.isRestricted ? (
                <div className="p-3.5 bg-slate-50 border-t border-slate-200 text-center text-xs font-semibold text-slate-700">
                  Messaging privileges are disabled on your account.
                </div>
              ) : (
                <form onSubmit={handleSendReply} className="p-3 bg-white border-t border-[#E2D6CE] flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Type your reply..."
                    value={replyMessage}
                    onChange={(e) => setReplyMessage(e.target.value)}
                    className="flex-1 text-xs p-2.5 bg-[#FFFDFB] rounded-xl border border-[#E2D6CE] focus:outline-none focus:border-[#FF4124]"
                  />
                  <button
                    type="submit"
                    disabled={!replyMessage.trim() || isSendingReply}
                    className="p-2.5 bg-gradient-to-r from-[#FF4124] to-[#FF8A28] text-white rounded-xl disabled:opacity-50 transition-opacity"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      )}
    </>
  );
}
export default SupportChatWidget;
