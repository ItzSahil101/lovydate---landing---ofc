"use client";

import { useState } from "react";
import Image from "next/image";

export default function InteractivePreview() {
  const [activeTab, setActiveTab] = useState("welcome");

  const tabs = [
    {
      id: "welcome",
      label: "Welcome",
      screen: "/assets/screen_welcome.png",
      alt: "Lovydate Welcome & Login Screen",
      title: "Seamless Welcome & Onboarding",
      description: "Simple, clean sign-in with Google or Email. Designed for a smooth and delightful first impression for singles in Nepal.",
    },
    {
      id: "profile",
      label: "Profile & Passion",
      screen: "/assets/screen_profile.png",
      alt: "Lovydate Profile Discovery Screen",
      title: "Discover Nearby Nepali Singles",
      description: "Explore authentic profiles like Shristi with distance badges, verified checks, lifestyle bios, and instant spark matching.",
    },
    {
      id: "feed",
      label: "Daily Moments",
      screen: "/assets/screen_feed.png",
      alt: "Lovydate Daily Moments Feed Screen",
      title: "Share Daily Life & Memories",
      description: "Post cafe memories, weekend hikes in Mardi Himal or Patan, and connect naturally over shared real-life moments through likes and comments.",
    },
    {
      id: "chat",
      label: "Direct Match Chat",
      screen: "/assets/screen_chat.png",
      alt: "Lovydate Direct Match Chat Screen",
      title: "Real-Time Mutual Conversations",
      description: "Unlocked direct messaging with online indicators, voice notes, media sharing, and natural Nepali conversations once you mutually match.",
    },
  ];

  const currentTab = tabs.find((t) => t.id === activeTab) || tabs[0];

  return (
    <section id="experience" className="py-24 relative overflow-hidden bg-white/70">
      {/* Background Lighting */}
      <div className="absolute top-1/2 left-1/3 w-96 h-96 bg-[#FF4124]/10 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-1/4 w-80 h-80 bg-[#FFA451]/15 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center px-3.5 py-1.5 rounded-full glass-card border border-[#FF6A2A]/30 text-xs font-bold text-[#FF4124]">
            <span>Real App Experience</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black font-outfit text-slate-900 tracking-tight">
            Explore <span className="text-gradient">Lovydate Screens</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg font-medium">
            Take a look at actual screenshots from the Lovydate Flutter mobile app designed for genuine dating in Nepal.
          </p>

          {/* Interactive Navigation Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 pt-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold transition-all duration-300 ${
                  activeTab === tab.id
                    ? "bg-gradient-to-r from-[#FF6A2A] to-[#FF4124] text-white shadow-lg shadow-[#FF4124]/30 scale-105"
                    : "bg-white text-slate-700 hover:text-slate-900 hover:bg-orange-50/80 border border-orange-200/60 shadow-sm"
                }`}
              >
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Live Interactive Phone Stage */}
        <div className="max-w-4xl mx-auto glass-card rounded-3xl p-6 sm:p-10 border border-orange-200/60 shadow-xl relative bg-white/90">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Phone Screen Mockup with Real App Screenshot */}
            <div className="lg:col-span-6 flex justify-center">
              <div className="w-full max-w-[300px] rounded-[2.8rem] bg-slate-950 border-[6px] border-slate-900 shadow-2xl overflow-hidden p-1.5 relative ring-4 ring-orange-100">
                {/* Real App Screenshot Image */}
                <div className="relative w-full rounded-[2.2rem] overflow-hidden bg-white aspect-[9/19.5] shadow-inner">
                  <Image
                    src={currentTab.screen}
                    alt={currentTab.alt}
                    fill
                    priority
                    className="object-cover object-top transition-all duration-500"
                  />
                </div>
              </div>
            </div>

            {/* Right Column: Dynamic Screen Explanation & Highlights */}
            <div className="lg:col-span-6 space-y-6">
              <div className="space-y-2">
                <div className="text-xs font-bold uppercase tracking-wider text-[#FF4124]">
                  {currentTab.label}
                </div>
                <h3 className="text-2xl sm:text-3xl font-extrabold font-outfit text-slate-900">
                  {currentTab.title}
                </h3>
                <p className="text-sm sm:text-base text-slate-600 font-medium leading-relaxed">
                  {currentTab.description}
                </p>
              </div>

              {/* 3 Key Pillars */}
              <div className="space-y-3.5 pt-2">
                <div className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-orange-200/60 shadow-sm hover:border-[#FF6A2A]/40 transition-colors">
                  <div className="inline-flex items-center px-3 py-1.5 rounded-xl bg-orange-100 text-[#FF4124] font-outfit font-black text-xs border border-orange-200 flex-shrink-0">
                    01
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Profile & Passions</h4>
                    <p className="text-xs text-slate-600 mt-0.5 font-medium">
                      Location-aware matchmaking, verified badges, and lifestyle bios across Nepal.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-orange-200/60 shadow-sm hover:border-[#FF6A2A]/40 transition-colors">
                  <div className="inline-flex items-center px-3 py-1.5 rounded-xl bg-orange-100 text-[#FF4124] font-outfit font-black text-xs border border-orange-200 flex-shrink-0">
                    02
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Daily Moments Feed</h4>
                    <p className="text-xs text-slate-600 mt-0.5 font-medium">
                      Share coffee visits, photography, and hiking updates with instant likes & comments.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-orange-200/60 shadow-sm hover:border-[#FF4124]/40 transition-colors">
                  <div className="inline-flex items-center px-3 py-1.5 rounded-xl bg-orange-100 text-[#FF4124] font-outfit font-black text-xs border border-orange-200 flex-shrink-0">
                    03
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Direct Match Chat</h4>
                    <p className="text-xs text-slate-600 mt-0.5 font-medium">
                      Connect naturally with text, voice notes, and media once mutual interest is shared.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
