"use client";

import Image from "next/image";
import { Sparkles, ArrowDown, Play, ShieldCheck, MapPin, Heart } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      {/* Background Decorative Warm Gradients / Sunrise Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] md:w-[900px] h-[550px] bg-gradient-to-tr from-[#FF6A2A]/15 via-[#FF4124]/10 to-[#FFA451]/15 rounded-full blur-3xl pointer-events-none -z-10 animate-pulse-glow" />
      <div className="absolute top-20 right-10 w-80 h-80 bg-[#FFA451]/15 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-[#FF4124]/10 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* Subtle grid pattern overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#FF6A2A08_1px,transparent_1px),linear-gradient(to_bottom,#FF6A2A08_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,#000_70%,transparent_100%)] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Headline & Call To Action */}
          <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
            {/* Pill Tag */}
            <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full glass-card border border-[#FF6A2A]/30 text-xs sm:text-sm font-semibold text-slate-800 shadow-sm">
              <span className="flex h-2 w-2 rounded-full bg-[#FF4124] animate-ping" />
              <span className="text-[#FF4124] font-bold">
                Launching Soon in Nepal • Early Access Open
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight font-outfit leading-[1.1] text-slate-900">
              Find Real Love <br />
              <span className="text-gradient">Across Nepal.</span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg lg:text-xl text-slate-600 max-w-2xl mx-auto lg:mx-0 font-medium leading-relaxed">
              Nepal&apos;s upcoming dating app built for authentic sparks, verified profiles, daily memories feed, and deep compatibility. Be among the first to join in Kathmandu, Pokhara, Lalitpur, and beyond.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <a
                href="#waitlist"
                className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-4 rounded-full text-base font-bold text-white bg-gradient-to-r from-[#FF6A2A] to-[#FF4124] hover:from-[#ff7940] hover:to-[#ff5238] orange-glow transition-all duration-300 transform hover:-translate-y-1 active:translate-y-0 shadow-lg shadow-[#FF4124]/30"
              >
                <span>Join Early Access Waitlist</span>
              </a>

              <a
                href="#experience"
                className="w-full sm:w-auto inline-flex items-center justify-center px-7 py-4 rounded-full text-base font-bold text-slate-800 glass-card hover:bg-white transition-all duration-300 border border-orange-200/70 hover:border-[#FF6A2A]/40 shadow-sm"
              >
                <span>Preview App Screens</span>
              </a>
            </div>

            {/* Launching Highlights */}
            <div className="pt-6 border-t border-orange-200/50 grid grid-cols-3 gap-4 max-w-lg mx-auto lg:mx-0">
              <div className="space-y-1 text-center lg:text-left">
                <div className="text-2xl sm:text-3xl font-black font-outfit text-slate-900">Nepal</div>
                <div className="text-xs text-slate-500 font-semibold">Nationwide Launch</div>
              </div>
              <div className="space-y-1 text-center lg:text-left">
                <div className="text-2xl sm:text-3xl font-black font-outfit text-[#FF6A2A] flex items-center justify-center lg:justify-start gap-1">
                  <span>VIP</span>
                </div>
                <div className="text-xs text-slate-500 font-semibold">Early Adopter Perks</div>
              </div>
              <div className="space-y-1 text-center lg:text-left">
                <div className="text-2xl sm:text-3xl font-black font-outfit text-[#FF4124]">100%</div>
                <div className="text-xs text-slate-500 font-semibold">Verified Community</div>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Showcase Card with Real App Login Screen */}
          <div className="lg:col-span-5 relative flex justify-center items-center">
            {/* Ambient Background Behind Mockup */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#FF4124]/20 via-[#FF6A2A]/15 to-[#FFA451]/20 rounded-[3rem] blur-2xl transform rotate-3 scale-95" />

            {/* Real App Phone Frame */}
            <div className="relative w-full max-w-[320px] rounded-[2.8rem] p-2 bg-slate-950 border-[6px] border-slate-900 shadow-2xl orange-glow-lg overflow-hidden ring-4 ring-orange-200/60">
              {/* Real App Welcome Screenshot */}
              <div className="relative rounded-[2.2rem] overflow-hidden bg-white aspect-[9/19.5] shadow-inner">
                <Image
                  src="/assets/screen_welcome.png"
                  alt="Lovydate Welcome App Screen"
                  fill
                  priority
                  className="object-cover object-top"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Down Indicator */}
      <div className="mt-16 flex justify-center">
        <a
          href="#experience"
          className="flex flex-col items-center gap-2 text-xs font-bold text-slate-500 hover:text-[#FF4124] transition-colors"
        >
          <span>Explore App Screens</span>
          <ArrowDown className="w-4 h-4 animate-bounce text-[#FF6A2A]" />
        </a>
      </div>
    </section>
  );
}
