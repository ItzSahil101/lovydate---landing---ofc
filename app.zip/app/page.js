import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import InteractivePreview from "@/components/InteractivePreview";
import FeaturesGrid from "@/components/FeaturesGrid";
import HowItWorks from "@/components/HowItWorks";
import SafetySection from "@/components/SafetySection";
import Testimonials from "@/components/Testimonials";
import FAQSection from "@/components/FAQSection";
import DownloadBanner from "@/components/DownloadBanner";
import Footer from "@/components/Footer";
import FloatingMascot from "@/components/FloatingMascot";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-[#FCF9F6] text-slate-900 selection:bg-[#FF4124] selection:text-white">
      {/* Sticky Glass Navbar */}
      <Navbar />

      {/* Main Landing Page Content */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero />

        {/* Live Interactive App Experience */}
        <InteractivePreview />

        {/* Bento Grid Features */}
        <FeaturesGrid />

        {/* How It Works (3-step walkthrough) */}
        <HowItWorks />

        {/* Safety & Identity Verification */}
        <SafetySection />

        {/* User Love Stories & Testimonials */}
        <Testimonials />

        {/* Frequently Asked Questions */}
        <FAQSection />

        {/* Final Download Call to Action */}
        <DownloadBanner />
      </main>

      {/* Floating Interactive Lovydate Mascot */}
      <FloatingMascot />

      {/* Footer */}
      <Footer />
    </div>
  );
}
