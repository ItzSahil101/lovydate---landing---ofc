import { NextResponse } from "next/server";

export async function POST(request) {
  try {
    const { contact } = await request.json();

    if (!contact || !contact.trim()) {
      return NextResponse.json(
        { error: "Please provide a valid email or phone number." },
        { status: 400 }
      );
    }

    const trimmedContact = contact.trim();
    const timestamp = new Date().toISOString();
    const formattedDate = new Date().toLocaleString("en-US", { timeZone: "Asia/Kathmandu" });
    const googleSheetUrl = process.env.GOOGLE_SHEET_WEBAPP_URL || process.env.NEXT_PUBLIC_GOOGLE_SHEET_URL;

    if (googleSheetUrl && googleSheetUrl.startsWith("http")) {
      try {
        const isSheetDb = googleSheetUrl.includes("sheetdb.io");

        // Exact column matching for SheetDB
        const payload = isSheetDb
          ? {
              data: [
                {
                  "Timestamp": formattedDate,
                  "Email / Phone Number": trimmedContact,
                  "ISO Date": timestamp,
                },
              ],
            }
          : {
              contact: trimmedContact,
              timestamp: formattedDate,
              isoDate: timestamp,
            };

        const response = await fetch(googleSheetUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify(payload),
        });

        if (!response.ok) {
          const errText = await response.text();
          console.warn("SheetDB/Google Sheet responded with:", response.status, errText);
        }
      } catch (err) {
        console.error("Error submitting to SheetDB:", err);
      }
    } else {
      console.log(`[Lovydate Early Access Pre-Registration] Contact: ${trimmedContact} at ${timestamp}`);
    }

    return NextResponse.json(
      {
        success: true,
        message: "Successfully joined the Lovydate Early Access list!",
        contact: trimmedContact,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Waitlist API Error:", error);
    return NextResponse.json(
      { error: "Internal server error. Please try again." },
      { status: 500 }
    );
  }
}
