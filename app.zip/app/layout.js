import { Plus_Jakarta_Sans, Outfit } from "next/font/google";
import "./globals.css";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-jakarta",
  display: "swap",
});

const outfit = Outfit({
  subsets: ["latin"],
  variable: "--font-outfit",
  display: "swap",
});

export const metadata = {
  metadataBase: new URL("https://lovydate.fun"),
  title: "Lovydate : Nepal's Premier Dating App for Meaningful Connections",
  description: "Lovydate is Nepal's modern dating app designed for authentic sparks, verified profiles, and deep funpatibility. Connect with singles across Kathmandu, Pokhara, and all over Nepal.",
  keywords: ["Lovydate", "dating app Nepal", "Nepali dating app", "Kathmandu dating", "Pokhara singles", "Nepal matrimony", "find love Nepal", "Nepali singles"],
  icons: {
    icon: "/assets/favicon_icon.png",
    shortcut: "/assets/favicon_icon.png",
    apple: "/assets/branding_icon.png",
  },
  openGraph: {
    title: "Lovydate : Nepal's Premier Dating App",
    description: "Discover genuine chemistry and meaningful dating with verified Nepali singles and smart spark matchmaking.",
    url: "https://lovydate.fun",
    siteName: "Lovydate Nepal",
    images: [
      {
        url: "/assets/nepali_couple.jpg",
        width: 1200,
        height: 630,
        alt: "Lovydate - Nepal's Premier Dating App",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Lovydate — Nepal's Premier Dating App",
    description: "Discover genuine chemistry and meaningful dating with verified Nepali singles and smart spark matchmaking.",
    images: ["/assets/nepali_couple.jpg"],
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${jakarta.variable} ${outfit.variable} scroll-smooth`}>
      <head>
        <link rel="icon" href="/assets/favicon_icon.png" sizes="any" />
      </head>
      <body className="font-sans antialiased bg-[#FCF9F6] text-slate-900 min-h-screen flex flex-col selection:bg-[#FF4124] selection:text-white">
        {children}
      </body>
    </html>
  );
}
